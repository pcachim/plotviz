# TO DO

- rename the tab 'annotate' to 'annotations'
- move 'subplot title' section from 'axes' to top of 'annotations' (below the subplot selector)
- move 'legend' section from 'axes' to 'annotations' bellow 'subplot title'
- add 'legend' configuration buttons (color, background, font, and other)
- add fine position adjustment besides the existing dropdown
- add a menu bar to the app just with tab titles that changes from tabs
- when double click in annotations show edit forms

- change the color scheme file type to .pvizc
- change the palette file type to .pvizp
- update bundle creation scripts to include the additional icons and register them
