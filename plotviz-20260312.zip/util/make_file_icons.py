#!/usr/bin/env python3
"""
make_file_icons.py  –  plotviz document-type icon generator
============================================================
Reads assets/plotviz.icns, extracts the largest embedded PNG,
then generates 1024×1024 document icons for:

    pviz_icon.png   – blue   (.pviz  – chart project)
    pvizt_icon.png  – amber  (.pvizt – chart template)
    pvizx_icon.png  – purple (.pvizx – palette bundle)

Output is written to assets/ (next to plotviz.icns).

Requirements:
    pip install Pillow

Usage:
    python make_file_icons.py                  # from repo root
    python make_file_icons.py --out /some/dir  # custom output dir
"""

from __future__ import annotations

import argparse
import io
import struct
import sys
from pathlib import Path

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    sys.exit("Pillow is required: pip install Pillow")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def extract_largest_png_from_icns(icns_path: Path) -> Image.Image:
    """Parse an ICNS file and return the largest embedded PNG as a PIL Image."""
    data = icns_path.read_bytes()
    if data[:4] != b"icns":
        raise ValueError(f"{icns_path} is not a valid ICNS file")

    pos = 8
    best_pixels = 0
    best_data: bytes | None = None

    while pos < len(data):
        chunk_size = struct.unpack(">I", data[pos + 4 : pos + 8])[0]
        payload = data[pos + 8 : pos + chunk_size]
        if payload[:8] == b"\x89PNG\r\n\x1a\n":
            img = Image.open(io.BytesIO(payload))
            if img.size[0] * img.size[1] > best_pixels:
                best_pixels = img.size[0] * img.size[1]
                best_data = payload
        pos += chunk_size

    if best_data is None:
        raise ValueError("No PNG chunks found in ICNS file")

    return Image.open(io.BytesIO(best_data)).convert("RGBA")


def _load_bold_font(size: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    """Return the best available bold font at *size* pt."""
    candidates = [
        "/System/Library/Fonts/Helvetica.ttc",
        "/System/Library/Fonts/SFNSDisplay.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
    ]
    for path in candidates:
        try:
            return ImageFont.truetype(path, size)
        except (IOError, OSError):
            pass
    return ImageFont.load_default()


# ---------------------------------------------------------------------------
# Core icon generator
# ---------------------------------------------------------------------------

ICON_SIZE = 1024

def make_document_icon(
    base_art: Image.Image,
    banner_rgb: tuple[int, int, int],
    label_text: str,
) -> Image.Image:
    """
    Compose a macOS-style document icon:
      • White rounded-rectangle page with folded top-right corner
      • Base artwork inset in the upper portion
      • Coloured bottom banner with white extension label
    """
    S = ICON_SIZE
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))

    # Layout constants
    RADIUS   = 80
    FOLD     = 180
    PAD_L    = 60
    PAD_R    = 60
    PAD_T    = 40
    PAD_B    = 40
    BANNER_H = 180
    ART_PAD  = 90

    pl = PAD_L
    pr = S - PAD_R
    pt = PAD_T
    pb = S - PAD_B

    # ── Drop shadow ──────────────────────────────────────────────────────────
    shadow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    sd = ImageDraw.Draw(shadow)
    for i in range(18, 0, -1):
        alpha = int(110 * (1 - i / 18))
        sd.rounded_rectangle(
            [pl + i, pt + i + 14, pr + i, pb + i + 14],
            radius=RADIUS, fill=(0, 0, 0, alpha),
        )
    img = Image.alpha_composite(img, shadow)
    draw = ImageDraw.Draw(img)

    # ── Page body ────────────────────────────────────────────────────────────
    draw.rounded_rectangle(
        [pl, pt, pr, pb],
        radius=RADIUS,
        fill=(255, 255, 255, 255),
        outline=(200, 200, 210, 255),
        width=3,
    )

    # ── Fold: erase top-right corner, draw shadow triangle + crease ─────────
    fold_x = pr - FOLD
    fold_y = pt + FOLD

    # Erase corner by painting transparent
    draw.polygon(
        [(fold_x, pt), (pr, pt), (pr, fold_y)],
        fill=(0, 0, 0, 0),
    )
    # Fold shadow fill
    draw.polygon(
        [(fold_x, pt), (pr, fold_y), (fold_x, fold_y)],
        fill=(218, 218, 232, 255),
    )
    # Fold crease lines
    draw.line([(fold_x, pt), (fold_x, fold_y), (pr, fold_y)],
              fill=(175, 175, 200, 255), width=3)
    draw.line([(fold_x, pt), (pr, fold_y)],
              fill=(200, 200, 215, 255), width=3)
    # Restore page outline segments
    draw.line([(pl + RADIUS, pt), (fold_x, pt)],
              fill=(200, 200, 210, 255), width=3)
    draw.line([(pr, fold_y), (pr, pb - RADIUS)],
              fill=(200, 200, 210, 255), width=3)

    # ── Base artwork (inset, avoids fold area) ───────────────────────────────
    art_left   = pl + ART_PAD
    art_top    = pt + ART_PAD
    art_right  = fold_x - 20
    art_bottom = pb - BANNER_H - 20
    art_w = art_right  - art_left
    art_h = art_bottom - art_top

    chart = base_art.copy()
    chart.thumbnail((art_w, art_h), Image.LANCZOS)
    cx = art_left + (art_w - chart.width)  // 2
    cy = art_top  + (art_h - chart.height) // 2
    img.alpha_composite(chart, (cx, cy))
    draw = ImageDraw.Draw(img)

    # ── Coloured banner clipped to page shape ────────────────────────────────
    banner_top = pb - BANNER_H

    page_mask = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(page_mask).rounded_rectangle(
        [pl, pt, pr, pb], radius=RADIUS, fill=(255, 255, 255, 255)
    )
    alpha_mask = page_mask.split()[3]

    banner_layer = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(banner_layer).rectangle(
        [pl, banner_top, pr, pb],
        fill=(*banner_rgb, 255),
    )
    clipped = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    clipped.paste(banner_layer, mask=alpha_mask)
    img = Image.alpha_composite(img, clipped)
    draw = ImageDraw.Draw(img)

    # ── Extension text centred in banner ────────────────────────────────────
    font = _load_bold_font(130)
    bbox = draw.textbbox((0, 0), label_text, font=font)
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]
    tx = (pl + pr) // 2 - tw // 2
    ty = banner_top + (BANNER_H - th) // 2 - bbox[1]
    draw.text((tx, ty), label_text, font=font, fill=(255, 255, 255, 255))

    return img


# ---------------------------------------------------------------------------
# File-type definitions
# ---------------------------------------------------------------------------

FILE_TYPES: list[tuple[str, tuple[int, int, int], str]] = [
    # (output stem,  banner RGB,          label)
    ("pviz_icon",  ( 52, 120, 220),  ".pviz"),   # blue  – chart project
    ("pvizt_icon", (210, 130,  20),  ".pvizt"),  # amber – template
    ("pvizx_icon", (140,  60, 200),  ".pvizx"),  # purple – palette bundle
]


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Generate plotviz file-type icons")
    ap.add_argument(
        "--icns",
        default=str(Path(__file__).parent / "assets" / "plotviz.icns"),
        help="Path to plotviz.icns  (default: assets/plotviz.icns)",
    )
    ap.add_argument(
        "--out",
        default=str(Path(__file__).parent / "assets"),
        help="Output directory  (default: assets/)",
    )
    args = ap.parse_args()

    icns_path = Path(args.icns)
    out_dir   = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f"Reading base icon from: {icns_path}")
    base_art = extract_largest_png_from_icns(icns_path)
    print(f"  → extracted {base_art.size[0]}×{base_art.size[1]} px base artwork")

    for stem, rgb, label in FILE_TYPES:
        icon = make_document_icon(base_art, rgb, label)
        out_path = out_dir / f"{stem}.png"
        icon.save(out_path, "PNG", optimize=True)
        print(f"  ✓ {out_path}  ({icon.size[0]}×{icon.size[1]})")

    print("Done.")


if __name__ == "__main__":
    main()
