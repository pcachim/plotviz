#!/usr/bin/env bash
# Advanced macOS icon pipeline

set -e

SRC="${1:-icon.svg}"

if [ ! -f "$SRC" ]; then
    echo "❌ Source icon not found: $SRC"
    exit 1
fi

EXT="${SRC##*.}"
BASE=$(basename "$SRC" .${EXT})

WORK=".iconbuild"
MASTER="${WORK}/master.png"
PADDED="${WORK}/padded.png"
ICONSET="${WORK}/${BASE}.iconset"
ICNS="${BASE}.icns"

rm -rf "$WORK"
mkdir -p "$WORK"
mkdir -p "$ICONSET"

echo "▶ Source: $SRC"

# ------------------------------------------------
# Convert source → 1024 PNG
# ------------------------------------------------
if [[ "$EXT" == "png" ]]; then
    sips -z 1024 1024 "$SRC" --out "$MASTER" >/dev/null
else
    qlmanage -t -s 1024 -o "$WORK" "$SRC" >/dev/null
    mv "$WORK/$(basename "$SRC").png" "$MASTER"
fi

# ------------------------------------------------
# Add macOS safe padding (~10%)
# ------------------------------------------------
SIZE=1024
PAD=920

sips -z $PAD $PAD "$MASTER" --out "$PADDED" >/dev/null

convert="$WORK/padded_canvas.png"

sips -c $SIZE $SIZE "$PADDED" --padColor FFFFFF --out "$convert" >/dev/null || cp "$PADDED" "$convert"

MASTER="$convert"

# ------------------------------------------------
# Generate iconset
# ------------------------------------------------
for size in 16 32 128 256 512; do
    sips -z $size $size "$MASTER" \
        --out "$ICONSET/icon_${size}x${size}.png" >/dev/null

    sips -z $((size*2)) $((size*2)) "$MASTER" \
        --out "$ICONSET/icon_${size}x${size}@2x.png" >/dev/null
done

cp "$MASTER" "$ICONSET/icon_512x512@2x.png"

# ------------------------------------------------
# Build icns
# ------------------------------------------------
echo "▶ Building .icns"
iconutil -c icns "$ICONSET" -o "$ICNS"

# ------------------------------------------------
# Export PNG for web / docs
# ------------------------------------------------
cp "$MASTER" "${BASE}.png"

rm -rf "$WORK"

echo "✅ Created:"
echo "   ${BASE}.icns"
echo "   ${BASE}.png"