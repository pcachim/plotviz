#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
#  make_icns.sh  –  Generate xd_frame.icns from a PNG or SVG
#
#  Requirements: macOS (uses iconutil, sips)
#  Input:        xd_frame_icon.png  (1024×1024 recommended)
#  Output:       xd_frame.icns
# ─────────────────────────────────────────────────────────────
set -e

SRC="${1:-icon.svg}"

if [ ! -f "$SRC" ]; then
    echo "❌ Source icon not found: $SRC"
    exit 1
fi

if [ ! -f "$SRC" ]; then
    echo "⚠  $SRC not found – generating a placeholder icon..."
    python3 - <<'PYEOF'
import struct, zlib

def make_png(w, h, color):
    """Minimal PNG writer."""
    def chunk(name, data):
        c = zlib.crc32(name + data) & 0xffffffff
        return struct.pack(">I", len(data)) + name + data + struct.pack(">I", c)
    ihdr = struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)
    raw = b"".join(b"\x00" + bytes(color) * w for _ in range(h))
    idat = zlib.compress(raw)
    png  = b"\x89PNG\r\n\x1a\n"
    png += chunk(b"IHDR", ihdr)
    png += chunk(b"IDAT", idat)
    png += chunk(b"IEND", b"")
    return png

# Dark navy background with a simple white square as placeholder
with open("xd_frame_icon.png", "wb") as f:
    f.write(make_png(1024, 1024, [30, 58, 95]))   # #1e3a5f
print("Placeholder icon written to xd_frame_icon.png")
PYEOF
fi

ICONSET="xd_frame.iconset"
mkdir -p "$ICONSET"

echo "▶  Generating icon sizes..."
for SIZE in 16 32 64 128 256 512 1024; do
    sips -z $SIZE $SIZE "$SRC" --out "${ICONSET}/icon_${SIZE}x${SIZE}.png"        > /dev/null
done
# Retina (@2x) variants
for SIZE in 16 32 128 256 512; do
    S2=$((SIZE * 2))
    sips -z $S2 $S2 "$SRC" --out "${ICONSET}/icon_${SIZE}x${SIZE}@2x.png"        > /dev/null
done

echo "▶  Converting to .icns..."
iconutil -c icns "$ICONSET" -o "$SRC.icns"

rm -rf "$ICONSET"
echo "✅ xd_frame.icns created"
