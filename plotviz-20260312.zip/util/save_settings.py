from pathlib import Path
import json
import tempfile
from platformdirs import user_config_dir

APP = "xd-chart"
CFG_DIR = Path(user_config_dir(APP))
CFG_FILE = CFG_DIR / "settings.json"

DEFAULTS = {"theme": "dark", "recent_files": [], "window_size": [1200, 800]}

CFG_DIR.mkdir(parents=True, exist_ok=True)

def load():
    if CFG_FILE.exists():
        return {**DEFAULTS, **json.loads(CFG_FILE.read_text())}
    return DEFAULTS.copy()

def save(data):
    with tempfile.NamedTemporaryFile("w", delete=False, dir=CFG_DIR) as tmp:
        json.dump(data, tmp, indent=2)
        Path(tmp.name).replace(CFG_FILE)

settings = load()
def get(k): return settings.get(k, DEFAULTS.get(k))
def set(k, v): settings[k] = v; save(settings)