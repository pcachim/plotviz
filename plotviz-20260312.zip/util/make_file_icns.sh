#!/usr/bin/env bash
# make_file_icns.sh  –  Convert plotviz file-type PNGs → .icns
# =============================================================
# Reads:   assets/pviz_icon.png, pvizt_icon.png, pvizx_icon.png
# Writes:  assets/pviz.icns, pvizt.icns, pvizx.icns
#
# Requirements:
#   macOS only — uses the built-in sips and iconutil tools.
#   Run make_file_icons.py first to generate the PNG sources.
#
# Usage:
#   chmod +x make_file_icns.sh
#   ./make_file_icns.sh

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ASSETS_DIR="$SCRIPT_DIR/assets"

# Check for required tools
if ! command -v iconutil &>/dev/null; then
    echo "Error: iconutil not found. This script requires macOS." >&2
    exit 1
fi
if ! command -v sips &>/dev/null; then
    echo "Error: sips not found. This script requires macOS." >&2
    exit 1
fi

# File type definitions: stem and source PNG (parallel arrays)
STEMS=(   "pviz"           "pvizt"           "pvizx"           )
SOURCES=( "pviz_icon.png"  "pvizt_icon.png"  "pvizx_icon.png"  )

# macOS ICNS 1x sizes
SIZES=(16 32 64 128 256 512 1024)

# HiDPI pairs: logical -> physical pixel size
HIDPI_LOGICAL=(  16  32   64  128  256  512 )
HIDPI_PHYSICAL=( 32  64  128  256  512 1024 )

echo "Building .icns files from PNGs in: $ASSETS_DIR"
echo ""

for i in "${!STEMS[@]}"; do
    STEM="${STEMS[$i]}"
    SOURCE_PNG="$ASSETS_DIR/${SOURCES[$i]}"

    if [[ ! -f "$SOURCE_PNG" ]]; then
        echo "  x Source not found: $SOURCE_PNG  (run make_file_icons.py first)"
        continue
    fi

    ICONSET="$ASSETS_DIR/${STEM}.iconset"
    rm -rf "$ICONSET"
    mkdir -p "$ICONSET"

    echo "  Processing $STEM ..."

    # 1x sizes
    for SIZE in "${SIZES[@]}"; do
        sips -z "$SIZE" "$SIZE" "$SOURCE_PNG" \
             --out "$ICONSET/icon_${SIZE}x${SIZE}.png" \
             &>/dev/null
    done

    # 2x (HiDPI) sizes
    for j in "${!HIDPI_LOGICAL[@]}"; do
        LOGICAL="${HIDPI_LOGICAL[$j]}"
        PHYSICAL="${HIDPI_PHYSICAL[$j]}"
        sips -z "$PHYSICAL" "$PHYSICAL" "$SOURCE_PNG" \
             --out "$ICONSET/icon_${LOGICAL}x${LOGICAL}@2x.png" \
             &>/dev/null
    done

    OUT_ICNS="$ASSETS_DIR/${STEM}.icns"
    iconutil -c icns "$ICONSET" -o "$OUT_ICNS"
    rm -rf "$ICONSET"

    echo "    -> $OUT_ICNS"
done

echo ""
echo "Done. ICNS files written to $ASSETS_DIR"
echo ""
echo "Add to Info.plist (CFBundleDocumentTypes):"
echo ""
echo '  <key>CFBundleDocumentTypes</key>'
echo '  <array>'
echo '    <dict>'
echo '      <key>CFBundleTypeName</key>        <string>plotviz Chart</string>'
echo '      <key>CFBundleTypeExtensions</key>  <array><string>pviz</string></array>'
echo '      <key>CFBundleTypeIconFile</key>    <string>pviz</string>'
echo '      <key>CFBundleTypeRole</key>        <string>Editor</string>'
echo '    </dict>'
echo '    <dict>'
echo '      <key>CFBundleTypeName</key>        <string>plotviz Template</string>'
echo '      <key>CFBundleTypeExtensions</key>  <array><string>pvizt</string></array>'
echo '      <key>CFBundleTypeIconFile</key>    <string>pvizt</string>'
echo '      <key>CFBundleTypeRole</key>        <string>Editor</string>'
echo '    </dict>'
echo '    <dict>'
echo '      <key>CFBundleTypeName</key>        <string>plotviz Palette Bundle</string>'
echo '      <key>CFBundleTypeExtensions</key>  <array><string>pvizx</string></array>'
echo '      <key>CFBundleTypeIconFile</key>    <string>pvizx</string>'
echo '      <key>CFBundleTypeRole</key>        <string>Editor</string>'
echo '    </dict>'
echo '  </array>'