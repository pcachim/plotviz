#!/bin/bash

APP_NAME="xd-chart"
APP_PATH="dist/${APP_NAME}.app"

VERSION=$(python - <<EOF
import tomllib
with open("pyproject.toml","rb") as f:
    data = tomllib.load(f)
print(data["project"]["version"])
EOF
)

DMG="dist/${APP_NAME}-${VERSION}.dmg"

echo "Building DMG version $VERSION"

create-dmg \
  --volname "$APP_NAME" \
  --window-pos 200 120 \
  --window-size 600 400 \
  --icon-size 120 \
  --icon "${APP_NAME}.app" 150 200 \
  --hide-extension "${APP_NAME}.app" \
  --app-drop-link 450 200 \
  --background "dmg/background.png" \
  "$DMG" \
  "$APP_PATH"

xattr -cr $DMG

echo "Created $DMG"