from PIL import Image, ImageDraw
import math

SIZE = 1024
CENTER = SIZE // 2


def radial_gradient(size, inner, outer):
    img = Image.new("RGB", (size, size))
    pixels = img.load()

    cx = cy = size // 2
    maxdist = math.sqrt(cx**2 + cy**2)

    for y in range(size):
        for x in range(size):
            d = math.sqrt((x - cx) ** 2 + (y - cy) ** 2) / maxdist
            r = int(inner[0] * (1 - d) + outer[0] * d)
            g = int(inner[1] * (1 - d) + outer[1] * d)
            b = int(inner[2] * (1 - d) + outer[2] * d)
            pixels[x, y] = (r, g, b)

    return img


def rounded_rect(draw, xy, r, fill):
    x1, y1, x2, y2 = xy
    draw.rounded_rectangle(xy, r, fill=fill)


def draw_chart(draw):
    bars = [0.3, 0.6, 0.5, 0.8, 0.7]
    width = 80
    spacing = 50
    start = 250

    for i, h in enumerate(bars):
        x = start + i * (width + spacing)
        y = 700 - int(h * 400)
        draw.rectangle((x, y, x + width, 700), fill=(80, 200, 120))

    points = []
    for i, v in enumerate([0.2, 0.4, 0.35, 0.6, 0.8]):
        x = start + i * (width + spacing) + width // 2
        y = 700 - int(v * 400)
        points.append((x, y))

    draw.line(points, fill=(255, 120, 0), width=12)

    for p in points:
        draw.ellipse((p[0] - 12, p[1] - 12, p[0] + 12, p[1] + 12),
                     fill=(255, 120, 0))


def draw_gear(draw, cx, cy, r, teeth):
    for i in range(teeth):
        angle = i * 360 / teeth
        x = cx + math.cos(math.radians(angle)) * r
        y = cy + math.sin(math.radians(angle)) * r
        draw.rectangle((x - 10, y - 10, x + 10, y + 10), fill=(200, 200, 210))

    draw.ellipse((cx - r, cy - r, cx + r, cy + r), fill=(220, 220, 230))
    draw.ellipse((cx - r * 0.4, cy - r * 0.4, cx + r * 0.4, cy + r * 0.4),
                 fill=(120, 120, 130))


def draw_palette(draw):
    draw.ellipse((250, 350, 750, 750), fill=(220, 180, 120))

    colors = [
        (240, 80, 80),
        (80, 180, 240),
        (120, 220, 120),
        (240, 220, 80),
        (180, 120, 240),
    ]

    positions = [
        (350, 500),
        (450, 420),
        (560, 520),
        (430, 620),
        (580, 620),
    ]

    for (x, y), c in zip(positions, colors):
        draw.ellipse((x - 35, y - 35, x + 35, y + 35), fill=c)


def draw_file_base():
    img = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    rounded_rect(draw, (150, 120, 880, 920), 60, (245, 245, 248))
    draw.polygon([(730, 120), (880, 120), (880, 260)], fill=(220, 220, 225))

    return img, draw


def create_app_icon():
    img = radial_gradient(SIZE, (60, 120, 200), (20, 30, 60))
    draw = ImageDraw.Draw(img)
    draw_chart(draw)
    img.save("icon_app.png")


def create_plot_icon():
    img, draw = draw_file_base()
    draw_chart(draw)
    img.save("icon_plot.png")


def create_settings_icon():
    img, draw = draw_file_base()
    draw_gear(draw, 520, 520, 160, 10)
    img.save("icon_settings.png")


def create_palette_icon():
    img, draw = draw_file_base()
    draw_palette(draw)
    img.save("icon_palette.png")


if __name__ == "__main__":
    create_app_icon()
    create_plot_icon()
    create_settings_icon()
    create_palette_icon()

    print("Icons generated:")
    print(" - icon_app.png")
    print(" - icon_plot.png")
    print(" - icon_settings.png")
    print(" - icon_palette.png")