from PIL import Image, ImageDraw, ImageFont

W, H = 600, 400

img = Image.new("RGB", (W, H), (245, 246, 248))
draw = ImageDraw.Draw(img)

# Title
title = "Install xd-chart"

# Instruction text
subtitle = "Drag the application to Applications"

# Try default font
font_large = ImageFont.load_default()
font_small = ImageFont.load_default()

# Draw title
draw.text((200, 40), title, fill=(30,30,30), font=font_large)

# Draw instruction
draw.text((150, 330), subtitle, fill=(90,90,90), font=font_small)

# Draw arrow
draw.line((260,200,340,200), fill=(120,120,120), width=6)
draw.polygon([(340,200),(320,185),(320,215)], fill=(120,120,120))

img.save("dmg/background.png")

print("background.png generated")